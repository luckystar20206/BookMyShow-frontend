import { createContext } from "react";

// Creating a new context.
const BsContext = createContext();

export default BsContext;